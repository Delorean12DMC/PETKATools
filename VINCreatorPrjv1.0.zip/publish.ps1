dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true /p:DebugType=None /p:DebugSymbols=false /p:PublishDir="$PSScriptRoot\publish"
Remove-Item "$PSScriptRoot\publish\*.pdb" -Force -ErrorAction SilentlyContinue
