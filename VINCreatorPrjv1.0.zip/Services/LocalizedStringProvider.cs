namespace VINCreator.Services
{
    public sealed class LocalizedStringProvider
    {
        public string this[string key] => LocalizationService.Instance[key];
    }
}
