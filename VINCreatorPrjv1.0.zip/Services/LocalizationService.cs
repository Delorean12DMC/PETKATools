using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.Json;
using CommunityToolkit.Mvvm.ComponentModel;

namespace VINCreator.Services
{
    public partial class LocalizationService : ObservableObject
    {
        public static readonly LocalizationService Instance = new();

        private Dictionary<string, string> _strings = [];

        [ObservableProperty]
        private string _language = string.Empty;

        partial void OnLanguageChanged(string value)
        {
            LoadStrings(value);
            OnPropertyChanged("Item[]");
        }

        public string this[string key] => _strings.GetValueOrDefault(key, $"[{key}]");

        public void Initialize(string language)
        {
            Language = language;
        }

        private void LoadStrings(string lang)
        {
            var resourceName = $"VINCreator.Assets.Localization.{lang}.json";
            using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
            if (stream is null) return;
            using var reader = new StreamReader(stream);
            var json = reader.ReadToEnd();
            _strings = JsonSerializer.Deserialize<Dictionary<string, string>>(json) ?? [];
        }
    }
}
