using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace VINCreator.Services
{
    public class LookupService
    {
        public static readonly LookupService Instance = new();

        private Dictionary<string, string> _lookup = [];

        public IReadOnlyDictionary<string, string> Entries => _lookup;

        public void Load()
        {
            using var stream = Assembly.GetExecutingAssembly()
                .GetManifestResourceStream("VINCreator.Assets.lookup.bin");

            if (stream is null) return;

            using var reader = new BinaryReader(stream, Encoding.UTF8);
            int count = reader.ReadInt32();
            _lookup = new Dictionary<string, string>(count, StringComparer.Ordinal);

            for (int i = 0; i < count; i++)
            {
                int packed = reader.ReadInt32();
                string key = DecodeKey(packed);
                ushort len = reader.ReadUInt16();
                string value = Encoding.UTF8.GetString(reader.ReadBytes(len));
                _lookup[key] = value;
            }
        }

        private static string DecodeKey(int packed)
        {
            char c0 = (char)((packed >> 16) & 0xFF);
            char c1 = (char)((packed >> 8) & 0xFF);
            char c2 = (char)(packed & 0xFF);
            return new string([c0, c1, c2]);
        }
    }
}
