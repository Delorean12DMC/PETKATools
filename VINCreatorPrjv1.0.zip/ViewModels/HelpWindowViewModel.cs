using System;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using CommunityToolkit.Mvvm.ComponentModel;
using VINCreator.Services;

namespace VINCreator.ViewModels
{
    public partial class HelpWindowViewModel : ViewModelBase
    {
        public LocalizationService L => LocalizationService.Instance;

        [ObservableProperty]
        private string _helpText = string.Empty;

        [ObservableProperty]
        private Bitmap? _imageBitmap;

        public void SetTopic(string topic)
        {
            var (helpKey, avares) = topic switch
            {
                "vin"             => ("help_vin",             "avares://VINCreator/Assets/Sticker1.png"),
                "model_code"      => ("help_model_code",      "avares://VINCreator/Assets/Sticker2.png"),
                "color_code"      => ("help_color_code",      "avares://VINCreator/Assets/Sticker3.png"),
                "engine_code"     => ("help_engine_code",     "avares://VINCreator/Assets/Sticker4.png"),
                "engine_number"   => ("help_engine_number",   "avares://VINCreator/Assets/Sticker5.png"),
                "transmission"    => ("help_transmission",    "avares://VINCreator/Assets/Sticker6.png"),
                "country_code"    => ("help_country_code",    "avares://VINCreator/Assets/Sticker7.png"),
                "model_year"      => ("help_model_year",      "avares://VINCreator/Assets/Sticker8.png"),
                "production_date" => ("help_production_date", null),
                "equipment_codes" => ("help_equipment_codes", "avares://VINCreator/Assets/Sticker9.png"),
                _                 => ("help_startup",         null)
            };

            HelpText = L[helpKey];
            ImageBitmap = avares is not null ? LoadBitmap(avares) : null;
        }

        private static Bitmap? LoadBitmap(string avares)
        {
            try
            {
                using var stream = AssetLoader.Open(new Uri(avares));
                return new Bitmap(stream);
            }
            catch { return null; }
        }
    }
}
