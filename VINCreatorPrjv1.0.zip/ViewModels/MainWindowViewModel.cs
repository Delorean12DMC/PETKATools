using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using Avalonia;
using Avalonia.Styling;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using VINCreator.Models;
using VINCreator.Services;

namespace VINCreator.ViewModels
{
    public partial class MainWindowViewModel : ViewModelBase
    {
        private readonly SettingsService _settingsService = new();
        private AppSettings _settings;
        private List<EquipmentCodeViewModel> _allEquipmentCodes = [];

        [ObservableProperty] private LocalizedStringProvider _l = new();

        partial void OnLChanged(LocalizedStringProvider value) => OnPropertyChanged(nameof(WindowTitle));

        public string WindowTitle => $"{L["app_title"]} - https://github.com/Delorean12DMC/PETKATools - 1.0";

        public MainWindowViewModel()
        {
            _settings = _settingsService.Load();
            LocalizationService.Instance.Initialize(_settings.Language);
            ApplyTheme(_settings.Theme);

            LoadEquipmentCodes();
            FilteredEquipmentCodes = new ObservableCollection<EquipmentCodeViewModel>(_allEquipmentCodes);

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SearchInput))
                UpdateFilter();

            if (e.PropertyName is nameof(InputVin) or nameof(InputModelCode) or nameof(InputColorCode)
                or nameof(InputEngineCode) or nameof(InputEngineNumber) or nameof(InputTransmissionCode)
                or nameof(InputCountryCode) or nameof(SelectedModelYear) or nameof(SelectedProductionDate)
                or nameof(NicknameInput))
            {
                HasUnsavedChanges = true;
            }
        }

        private void LoadEquipmentCodes()
        {
            LookupService.Instance.Load();
            _allEquipmentCodes = LookupService.Instance.Entries
                .Select(kv =>
                {
                    var vm = new EquipmentCodeViewModel(kv.Key, kv.Value);
                    vm.SelectionChanged += OnEquipmentCodeSelectionChanged;
                    return vm;
                })
                .OrderBy(ec => ec.Code)
                .ToList();
        }

        private void OnEquipmentCodeSelectionChanged(object? sender, bool selected)
        {
            if (sender is not EquipmentCodeViewModel vm) return;
            if (selected)
            {
                if (!SelectedEquipmentCodes.Contains(vm))
                    SelectedEquipmentCodes.Add(vm);
            }
            else
            {
                SelectedEquipmentCodes.Remove(vm);
            }
            HasUnsavedChanges = true;
        }

        private void UpdateFilter()
        {
            FilteredEquipmentCodes.Clear();
            var query = SearchInput.Trim();
            var results = string.IsNullOrEmpty(query)
                ? _allEquipmentCodes
                : _allEquipmentCodes
                    .Where(ec => ec.Code.Contains(query, StringComparison.OrdinalIgnoreCase)
                              || ec.Description.Contains(query, StringComparison.OrdinalIgnoreCase))
                    .ToList();

            foreach (var item in results)
                FilteredEquipmentCodes.Add(item);

            OnPropertyChanged(nameof(FilteredCount));
        }

        public int FilteredCount => FilteredEquipmentCodes.Count;

        // ── Language & Theme ────────────────────────────────────────────────

        private static readonly Dictionary<string, string> _langCodeToDisplay = new()
        {
            { "de", "Deutsch" }, { "en", "English" }
        };
        private static readonly Dictionary<string, string> _langDisplayToCode = new()
        {
            { "Deutsch", "de" }, { "English", "en" }
        };

        public string[] AvailableLanguages { get; } = ["Deutsch", "English"];
        public string[] AvailableThemes { get; } = ["System", "Light", "Dark"];

        public string CurrentLanguage
        {
            get => _langCodeToDisplay.GetValueOrDefault(_settings.Language, _settings.Language);
            set
            {
                var code = _langDisplayToCode.GetValueOrDefault(value, value);
                if (_settings.Language == code) return;
                _settings.Language = code;
                LocalizationService.Instance.Language = code;
                _settingsService.Save(_settings);
                OnPropertyChanged(nameof(CurrentLanguage));
                L = new LocalizedStringProvider();  // new object reference forces compiled bindings to re-evaluate
            }
        }

        public string CurrentTheme
        {
            get => _settings.Theme;
            set
            {
                if (_settings.Theme == value) return;
                _settings.Theme = value;
                ApplyTheme(value);
                _settingsService.Save(_settings);
                OnPropertyChanged(nameof(CurrentTheme));
            }
        }

        private static void ApplyTheme(string theme)
        {
            if (Application.Current is null) return;
            Application.Current.RequestedThemeVariant = theme switch
            {
                "Light" => ThemeVariant.Light,
                "Dark"  => ThemeVariant.Dark,
                _       => ThemeVariant.Default
            };
        }

        // ── VIN Fields ──────────────────────────────────────────────────────

        [ObservableProperty] private string _inputVin = string.Empty;
        [ObservableProperty] private string _inputModelCode = string.Empty;
        [ObservableProperty] private string _inputColorCode = string.Empty;
        [ObservableProperty] private string _inputEngineCode = string.Empty;
        [ObservableProperty] private string _inputEngineNumber = string.Empty;
        [ObservableProperty] private string _inputTransmissionCode = string.Empty;
        [ObservableProperty] private string _inputCountryCode = string.Empty;
        [ObservableProperty] private string _nicknameInput = string.Empty;
        [ObservableProperty] private DateTime? _selectedProductionDate;
        [ObservableProperty] private ModelYear? _selectedModelYear;

        // ── Nickname mode ────────────────────────────────────────────────────

        private bool _useVinAsNickname;
        public bool UseVinAsNickname
        {
            get => _useVinAsNickname;
            set
            {
                if (_useVinAsNickname == value) return;
                _useVinAsNickname = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(UseCustomNickname));
                NicknameInput = InputVin;
            }
        }
        public bool UseCustomNickname
        {
            get => !_useVinAsNickname;
            set => UseVinAsNickname = !value;
        }

        // ── Equipment Codes ─────────────────────────────────────────────────

        [ObservableProperty] private string _searchInput = string.Empty;
        [ObservableProperty] private ObservableCollection<EquipmentCodeViewModel> _filteredEquipmentCodes = [];
        [ObservableProperty] private ObservableCollection<EquipmentCodeViewModel> _selectedEquipmentCodes = [];

        // ── VIN validation hint ─────────────────────────────────────────────

        public bool VinIsInvalid => InputVin.Length > 0 && InputVin.Length < 17;

        // ── Equipment code selection ─────────────────────────────────────────

        [RelayCommand]
        private void ClearSelection()
        {
            foreach (var ec in SelectedEquipmentCodes.ToList())
                ec.IsSelected = false;
            SelectedEquipmentCodes.Clear();
        }

        // ── Dirty State ─────────────────────────────────────────────────────

        [ObservableProperty] private bool _hasUnsavedChanges;

        // ── Model Years ─────────────────────────────────────────────────────

        partial void OnSelectedModelYearChanged(ModelYear? value)
        {
            if (value is null || !int.TryParse(value.Year, out var year)) return;
            if (SelectedProductionDate.HasValue)
            {
                var d = SelectedProductionDate.Value;
                var day = Math.Min(d.Day, DateTime.DaysInMonth(year, d.Month));
                SelectedProductionDate = new DateTime(year, d.Month, day);
            }
            else
            {
                SelectedProductionDate = new DateTime(year, 1, 1);
            }
        }

        partial void OnInputVinChanged(string value)
        {
            if (UseVinAsNickname)
                NicknameInput = value;
            OnPropertyChanged(nameof(VinIsInvalid));
            OnPropertyChanged(nameof(FilteredModelYears));
            var filtered = FilteredModelYears;
            if (filtered.Count == 1)
                SelectedModelYear = filtered[0];
            else if (SelectedModelYear is not null && !filtered.Contains(SelectedModelYear))
                SelectedModelYear = null;
        }

        public List<ModelYear> FilteredModelYears
        {
            get
            {
                if (InputVin.Length < 10) return ModelYears;
                var code = InputVin[9].ToString().ToUpperInvariant();
                var matches = ModelYears.Where(y => y.Code == code).ToList();
                return matches.Count > 0 ? matches : ModelYears;
            }
        }

        public List<ModelYear> ModelYears { get; } =
        [
            new("G", "1986"), new("H", "1987"), new("J", "1988"), new("K", "1989"), new("L", "1990"),
            new("M", "1991"), new("N", "1992"), new("P", "1993"), new("R", "1994"), new("S", "1995"),
            new("T", "1996"), new("V", "1997"), new("W", "1998"), new("X", "1999"), new("Y", "2000"),
            new("1", "2001"), new("2", "2002"), new("3", "2003"), new("4", "2004"), new("5", "2005"),
            new("6", "2006"), new("7", "2007"), new("8", "2008"), new("9", "2009"), new("A", "2010"),
            new("B", "2011"), new("C", "2012"), new("D", "2013"), new("E", "2014"), new("F", "2015"),
            new("G", "2016"), new("H", "2017"), new("J", "2018"), new("K", "2019"), new("L", "2020"),
            new("M", "2021"), new("N", "2022"), new("P", "2023"), new("R", "2024"), new("S", "2025"),
            new("T", "2026"), new("V", "2027")
        ];

        // ── File I/O ────────────────────────────────────────────────────────

        public void LoadFromFile(string[] parts)
        {
            if (parts.Length < 11) return;
            InputVin              = parts[0];
            InputModelCode        = parts[1];
            InputColorCode        = parts[2];
            InputEngineCode       = parts[3];
            InputEngineNumber     = parts[4];
            InputTransmissionCode = parts[5];
            // parts[6] reserved "000"
            if (DateTime.TryParseExact(parts[7], "ddMMyyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out var date))
                SelectedProductionDate = date;

            InputCountryCode = parts[8];

            SelectedModelYear = parts[9].Length == 4
                ? ModelYears.FirstOrDefault(y => y.Year == parts[9])
                : ModelYears.FirstOrDefault(y => y.Code == parts[9]);

            // Restore checked equipment codes
            foreach (var ec in SelectedEquipmentCodes.ToList())
                ec.IsSelected = false;
            SelectedEquipmentCodes.Clear();

            if (parts[10].Length >= 3)
            {
                for (int i = 0; i <= parts[10].Length - 3; i += 3)
                {
                    var code = parts[10].Substring(i, 3);
                    var match = _allEquipmentCodes.FirstOrDefault(ec => ec.Code == code);
                    if (match is not null) match.IsSelected = true;
                }
            }

            HasUnsavedChanges = false;
        }

        public string BuildFileLine()
        {
            var codes = string.Concat(SelectedEquipmentCodes.Select(ec => ec.Code));
            var date = SelectedProductionDate?.ToString("ddMMyyyy") ?? string.Empty;
            return $"{InputVin};{InputModelCode};{InputColorCode};{InputEngineCode};" +
                   $"{InputEngineNumber};{InputTransmissionCode};000;{date};" +
                   $"{InputCountryCode};{SelectedModelYear?.Year};{codes}";

        }

        public void ClearAll()
        {
            UseVinAsNickname = false;
            InputVin = InputModelCode = InputColorCode = InputEngineCode =
            InputEngineNumber = InputTransmissionCode = InputCountryCode = NicknameInput = string.Empty;
            SelectedProductionDate = null;
            SelectedModelYear = null;
            SearchInput = string.Empty;

            foreach (var ec in SelectedEquipmentCodes.ToList())
                ec.IsSelected = false;
            SelectedEquipmentCodes.Clear();

            HasUnsavedChanges = false;
        }

        public bool ValidateVin() => InputVin.Length == 17;
        public bool ValidateNickname() => !string.IsNullOrWhiteSpace(NicknameInput);
        public bool ValidateForSave() => ValidateVin() && ValidateNickname();

        // ── Window state ────────────────────────────────────────────────────

        public (double W, double H) GetWindowSize() =>
            (_settings.WindowWidth, _settings.WindowHeight);

        public void SaveWindowSize(double w, double h)
        {
            _settings.WindowWidth = w;
            _settings.WindowHeight = h;
            _settingsService.Save(_settings);
        }
    }

    public record ModelYear(string Code, string Year)
    {
        public string Display => $"{Code} = {Year}";
    }
}
