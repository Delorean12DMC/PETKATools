using System;
using CommunityToolkit.Mvvm.ComponentModel;

namespace VINCreator.ViewModels
{
    public partial class EquipmentCodeViewModel : ObservableObject
    {
        public string Code { get; }
        public string Description { get; }

        [ObservableProperty]
        private bool _isSelected;

        public event EventHandler<bool>? SelectionChanged;

        public EquipmentCodeViewModel(string code, string description)
        {
            Code = code;
            Description = description;
        }

        partial void OnIsSelectedChanged(bool value) =>
            SelectionChanged?.Invoke(this, value);

        public override string ToString() => $"{Code} — {Description}";
    }
}
