﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace VINCreator.ViewModels
{
    public abstract class ViewModelBase : ObservableObject
    {
    }
}
