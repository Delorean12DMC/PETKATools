using Avalonia.Controls;
using Avalonia.Interactivity;
using VINCreator.ViewModels;

namespace VINCreator.Views
{
    public partial class HelpWindow : Window
    {
        public HelpWindow() : this("startup") { }

        public HelpWindow(string topic)
        {
            InitializeComponent();
            var vm = new HelpWindowViewModel();
            vm.SetTopic(topic);
            DataContext = vm;
        }

        private void OnOkClick(object? sender, RoutedEventArgs e) => Close();
    }
}
