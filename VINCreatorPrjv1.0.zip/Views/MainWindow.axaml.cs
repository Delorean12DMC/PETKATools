using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using VINCreator.Services;
using VINCreator.ViewModels;

namespace VINCreator.Views
{
    public partial class MainWindow : Window
    {
        private static readonly string SaveFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "Digital-Eliteboard", "PETKA", "USERDATA", "FGST");

        private MainWindowViewModel Vm => (MainWindowViewModel)DataContext!;

        public MainWindow()
        {
            InitializeComponent();
            Closing += OnWindowClosing;
            Opened += OnWindowOpened;
            Closed += OnWindowClosed;
        }

        private void OnWindowOpened(object? sender, EventArgs e)
        {
            var (w, h) = Vm.GetWindowSize();
            Width = w;
            Height = h;
        }

        private void OnWindowClosed(object? sender, EventArgs e) =>
            Vm.SaveWindowSize(Width, Height);

        // ── Exit confirmation ────────────────────────────────────────────

        private async void OnWindowClosing(object? sender, WindowClosingEventArgs e)
        {
            if (!Vm.HasUnsavedChanges) return;

            e.Cancel = true;
            var result = await ShowUnsavedDialog();

            if (result == "save")
            {
                if (await TrySaveAsync())
                    Close();
            }
            else if (result == "discard")
            {
                Vm.HasUnsavedChanges = false;
                Close();
            }
            // "cancel" → do nothing, window stays open
        }

        private async Task<string> ShowUnsavedDialog()
        {
            var L = LocalizationService.Instance;
            var dialog = new Window
            {
                Title = L["dialog_unsaved_title"],
                Width = 400,
                Height = 160,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                CanResize = false
            };

            string result = "cancel";

            var save    = new Button { Content = L["dialog_save"],       MinWidth = 90 };
            var discard = new Button { Content = L["dialog_dont_save"],  MinWidth = 90 };
            var cancel  = new Button { Content = L["dialog_cancel"],     MinWidth = 90 };

            save.Click    += (_, _) => { result = "save";    dialog.Close(); };
            discard.Click += (_, _) => { result = "discard"; dialog.Close(); };
            cancel.Click  += (_, _) => { result = "cancel";  dialog.Close(); };

            dialog.Content = new StackPanel
            {
                Margin = new Avalonia.Thickness(20),
                Spacing = 16,
                Children =
                {
                    new TextBlock { Text = L["dialog_unsaved_message"], TextWrapping = Avalonia.Media.TextWrapping.Wrap },
                    new StackPanel
                    {
                        Orientation = Avalonia.Layout.Orientation.Horizontal,
                        Spacing = 8,
                        HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right,
                        Children = { save, discard, cancel }
                    }
                }
            };

            await dialog.ShowDialog(this);
            return result;
        }

        // ── Help ─────────────────────────────────────────────────────────

        private void OnHelpClick(object? sender, RoutedEventArgs e)
        {
            if (sender is not Button button || button.Tag is not string topic) return;

            var vm = new HelpWindowViewModel();
            vm.SetTopic(topic);

            var image = new Image
            {
                Source = vm.ImageBitmap,
                MaxHeight = 200,
                Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var text = new TextBlock
            {
                Text = vm.HelpText,
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 360,
                Margin = new Avalonia.Thickness(0, 8, 0, 0)
            };

            var panel = new StackPanel
            {
                Spacing = 4,
                Margin = new Avalonia.Thickness(4),
                Children = { image, text }
            };

            var flyout = new Flyout
            {
                Content = new ScrollViewer
                {
                    Content = panel,
                    MaxHeight = 420,
                    Width = 380
                }
            };

            flyout.ShowAt(button);
        }

        // ── Keyboard shortcuts ────────────────────────────────────────────

        private async void OnKeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyModifiers != KeyModifiers.Control) return;
            switch (e.Key)
            {
                case Key.S:
                    e.Handled = true;
                    await TrySaveAsync();
                    break;
                case Key.O:
                    e.Handled = true;
                    await OpenFileAsync();
                    break;
                case Key.Delete:
                    e.Handled = true;
                    Vm.ClearAll();
                    break;
            }
        }

        // ── Open ─────────────────────────────────────────────────────────

        private async void OnOpenClick(object? sender, RoutedEventArgs e) => await OpenFileAsync();

        private async Task OpenFileAsync()
        {
            var options = new FilePickerOpenOptions
            {
                Title = LocalizationService.Instance["dialog_open_title"],
                AllowMultiple = false,
                FileTypeFilter = [new FilePickerFileType("TXT") { Patterns = ["*.txt"] }],
                SuggestedStartLocation = await TryGetFolderAsync(SaveFolder)
            };

            var files = await StorageProvider.OpenFilePickerAsync(options);
            if (files.Count == 0) return;

            var text = await File.ReadAllTextAsync(files[0].Path.LocalPath);
            var parts = text.Trim().Split(';');
            Vm.LoadFromFile(parts);

            Vm.NicknameInput = Path.GetFileNameWithoutExtension(files[0].Name);
        }

        // ── Save ─────────────────────────────────────────────────────────

        private async void OnSaveClick(object? sender, RoutedEventArgs e) => await TrySaveAsync();

        private async Task<bool> TrySaveAsync()
        {
            var L = LocalizationService.Instance;

            if (!Vm.ValidateVin())
            {
                await ShowMessageAsync(L["msg_vin_error"]);
                return false;
            }

            if (!Vm.ValidateNickname())
            {
                await ShowMessageAsync(L["msg_nickname_error"]);
                return false;
            }

            var filename = Vm.NicknameInput.Trim();
            var filePath = Path.Combine(SaveFolder, $"{filename}.txt");

            if (File.Exists(filePath))
            {
                var overwrite = await ShowConfirmAsync(
                    L["dialog_overwrite_title"],
                    string.Format(L["dialog_overwrite_message"], filename));
                if (!overwrite) return false;
            }

            Directory.CreateDirectory(SaveFolder);
            File.WriteAllText(filePath, Vm.BuildFileLine());
            Vm.HasUnsavedChanges = false;
            await ShowMessageAsync(string.Format(L["msg_save_success"], filename));
            return true;
        }

        // ── Clear ─────────────────────────────────────────────────────────

        private void OnClearClick(object? sender, RoutedEventArgs e) => Vm.ClearAll();

        // ── Input: force uppercase ─────────────────────────────────────

        private static bool _isUpdatingText;
        private void OnUpperCaseTextChanged(object? sender, TextChangedEventArgs e)
        {
            if (_isUpdatingText || sender is not TextBox tb) return;
            var upper = tb.Text?.ToUpperInvariant() ?? string.Empty;
            if (tb.Text == upper) return;
            _isUpdatingText = true;
            tb.Text = upper;
            tb.CaretIndex = upper.Length;
            _isUpdatingText = false;
        }

        // Valid PR code characters — O (letter) is intentionally absent to avoid confusion with 0
        private static readonly System.Collections.Generic.HashSet<char> ValidPrChars =
            new("#0123456789ABCDEFGHIJKLMNPQRSTUVWXYZ");

        private void OnSearchInputChanged(object? sender, TextChangedEventArgs e)
        {
            if (_isUpdatingText || sender is not TextBox tb) return;
            var sanitized = new string((tb.Text ?? string.Empty)
                .ToUpperInvariant()
                .Where(ValidPrChars.Contains)
                .ToArray());
            if (tb.Text == sanitized) return;
            _isUpdatingText = true;
            tb.Text = sanitized;
            tb.CaretIndex = sanitized.Length;
            _isUpdatingText = false;
        }

        // ── Helpers ──────────────────────────────────────────────────────

        private async Task<IStorageFolder?> TryGetFolderAsync(string path)
        {
            try
            {
                if (!Directory.Exists(path)) return null;
                return await StorageProvider.TryGetFolderFromPathAsync(path);
            }
            catch { return null; }
        }

        private async Task ShowMessageAsync(string message)
        {
            var dialog = new Window
            {
                Title = LocalizationService.Instance["app_title"],
                Width = 380, Height = 140,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                CanResize = false
            };
            var ok = new Button { Content = "OK", MinWidth = 80, HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right };
            ok.Click += (_, _) => dialog.Close();
            dialog.Content = new StackPanel
            {
                Margin = new Avalonia.Thickness(20),
                Spacing = 16,
                Children =
                {
                    new TextBlock { Text = message, TextWrapping = Avalonia.Media.TextWrapping.Wrap },
                    ok
                }
            };
            await dialog.ShowDialog(this);
        }

        private async Task<bool> ShowConfirmAsync(string title, string message)
        {
            var dialog = new Window
            {
                Title = title,
                Width = 400, Height = 150,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                CanResize = false
            };
            bool result = false;
            var yes = new Button { Content = LocalizationService.Instance["dialog_save"], MinWidth = 90 };
            var no  = new Button { Content = LocalizationService.Instance["dialog_cancel"], MinWidth = 90 };
            yes.Click += (_, _) => { result = true;  dialog.Close(); };
            no.Click  += (_, _) => { result = false; dialog.Close(); };
            dialog.Content = new StackPanel
            {
                Margin = new Avalonia.Thickness(20),
                Spacing = 16,
                Children =
                {
                    new TextBlock { Text = message, TextWrapping = Avalonia.Media.TextWrapping.Wrap },
                    new StackPanel
                    {
                        Orientation = Avalonia.Layout.Orientation.Horizontal,
                        Spacing = 8,
                        HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right,
                        Children = { yes, no }
                    }
                }
            };
            await dialog.ShowDialog(this);
            return result;
        }
    }
}
