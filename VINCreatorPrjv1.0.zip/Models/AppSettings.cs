namespace VINCreator.Models
{
    public class AppSettings
    {
        public string Language { get; set; } = "de";
        public string Theme { get; set; } = "System";
        public double WindowWidth { get; set; } = 1000;
        public double WindowHeight { get; set; } = 660;
    }
}
